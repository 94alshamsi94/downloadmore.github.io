import os
import requests
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from threading import Thread, Event
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageTk
import pygame

DOWNLOAD_FOLDER = "downloads"
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

pause_event = Event()
pause_event.set()


def get_archive_links(url, extensions):
    response = requests.get(url)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    links = [
        urljoin(url, a_tag['href'])
        for a_tag in soup.find_all('a', href=True)
        if any(a_tag['href'].endswith(ext) for ext in extensions)
    ]
    return links


def download_file(url, progress_var, log_box):
    global DOWNLOAD_FOLDER
    local_filename = os.path.join(DOWNLOAD_FOLDER, os.path.basename(url))

    if os.path.exists(local_filename):
        base, ext = os.path.splitext(local_filename)
        local_filename = f"{base}_{int(time.time())}{ext}"

    with requests.get(url, stream=True, allow_redirects=True) as response:
        if response.status_code == 404:
            log_box.insert(tk.END, f"404 Not Found: {url}\n")
            return

        response.raise_for_status()
        total_size = int(response.headers.get('content-length', 0))
        with open(local_filename, 'wb') as file:
            chunk_size = 8192
            total_chunks = total_size // chunk_size
            for i, chunk in enumerate(response.iter_content(chunk_size=chunk_size)):
                pause_event.wait()
                file.write(chunk)
                progress_var.set((i + 1) / total_chunks * 100)
                root.update_idletasks()
    log_box.insert(tk.END, f"Downloaded: {local_filename}\n")


def toggle_pause():
    if pause_event.is_set():
        pause_event.clear()
        pause_button.config(text="Resume")
    else:
        pause_event.set()
        pause_button.config(text="Pause")


def toggle_music():
    if pygame.mixer.music.get_busy():
        pygame.mixer.music.pause()
        mute_button.config(text="Unmute")
    else:
        pygame.mixer.music.unpause()
        mute_button.config(text="Mute")


def start_download_thread(progress_var, log_box):
    thread = Thread(target=start_download, args=(progress_var, log_box))
    thread.daemon = True
    thread.start()


def start_download(progress_var, log_box):
    url = url_entry.get()
    extensions = ext_entry.get().split(',')
    threads = int(thread_entry.get())

    if not url or not extensions:
        messagebox.showerror("Error", "Please provide URL and file extensions.")
        return

    progress_var.set(0)
    log_box.delete(1.0, tk.END)
    log_box.insert(tk.END, "Fetching links...\n")
    links = get_archive_links(url, extensions)
    log_box.insert(tk.END, f"Found {len(links)} files to download.\n")
    if not links:
        messagebox.showwarning("No Files", "No files with the selected extensions found!")
        return

    with ThreadPoolExecutor(max_workers=threads) as executor:
        for link in links:
            executor.submit(download_file, link, progress_var, log_box)


def select_save_directory():
    global DOWNLOAD_FOLDER
    folder_selected = filedialog.askdirectory(initialdir=DOWNLOAD_FOLDER)
    if folder_selected:
        DOWNLOAD_FOLDER = folder_selected
        save_directory_label.config(text=f"Save Directory: {DOWNLOAD_FOLDER}")


def play_background_music():
    pygame.mixer.init()
    pygame.mixer.music.load("background_music.mp3")
    pygame.mixer.music.set_volume(0.2)
    pygame.mixer.music.play(-1)


def create_gui():
    global root, url_entry, ext_entry, thread_entry, progress_var, save_directory_label, pause_button, mute_button, log_box

    root = tk.Tk()
    root.title(" Download More ")
    root.geometry("900x600")
    root.configure(bg='#2c3e50')

    play_background_music()

    logo_image = Image.open("logo.png")
    logo_image = logo_image.resize((200, 100), Image.Resampling.LANCZOS)
    logo_photo = ImageTk.PhotoImage(logo_image)
    logo_label = tk.Label(root, image=logo_photo, bg='#2c3e50')
    logo_label.image = logo_photo
    logo_label.pack(pady=10)

    header_label = ttk.Label(root, text="Download More by Yahya Alshamsi for Usage instruction in our site", font=("Andalus", 18, "bold"), background="#2c3e50", foreground="white")
    header_label.pack(pady=15)

    ttk.Label(root, text="Base URL:", font=("Andalus", 12), background="#2c3e50", foreground="white").pack(pady=5, anchor="w", padx=20)
    url_entry = ttk.Entry(root, width=80, font=("Andalus", 12))
    url_entry.pack(pady=5, padx=20)

    ttk.Label(root, text="File Extensions (comma-separated):", font=("Andalus", 12), background="#2c3e50", foreground="white").pack(pady=5, anchor="w", padx=20)
    ext_entry = ttk.Entry(root, width=80, font=("Andalus", 12))
    ext_entry.pack(pady=5, padx=20)

    ttk.Label(root, text="Number of Threads:", font=("Andalus", 12), background="#2c3e50", foreground="white").pack(pady=5, anchor="w", padx=20)
    thread_entry = ttk.Entry(root, width=80, font=("Andalus", 12))
    thread_entry.insert(0, "4")
    thread_entry.pack(pady=5, padx=20)

    save_button = ttk.Button(root, text="Select Save Directory", command=select_save_directory)
    save_button.pack(pady=5)
    save_directory_label = ttk.Label(root, text=f"Save Directory: {DOWNLOAD_FOLDER}", font=("Andalus", 12), background="#2c3e50", foreground="white")
    save_directory_label.pack(pady=5)

    progress_var = tk.DoubleVar()
    ttk.Button(root, text="Start Download", command=lambda: start_download_thread(progress_var, log_box)).pack(pady=15)

    ttk.Progressbar(root, variable=progress_var, maximum=100, length=700).pack(pady=10)

    log_box = tk.Text(root, wrap=tk.WORD, height=10, width=90, bg="#34495e", fg="white", font=("Andalus", 10))
    log_box.pack(pady=10)

    button_frame = ttk.Frame(root)
    button_frame.pack(pady=15)

    pause_button = ttk.Button(button_frame, text="Pause", command=toggle_pause)
    pause_button.grid(row=0, column=0, padx=10)

    mute_button = ttk.Button(button_frame, text="Mute", command=toggle_music)
    mute_button.grid(row=0, column=1, padx=10)

    root.mainloop()


if __name__ == "__main__":
    create_gui()
